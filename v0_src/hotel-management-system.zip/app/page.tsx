export default function Page() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-950 p-8">
      <div className="max-w-2xl text-center">
        <h1 className="mb-4 text-4xl font-bold text-white">Hotel Management System</h1>
        <p className="mb-6 text-lg text-gray-400">This is a Vite + React + TypeScript application.</p>
        <div className="rounded-lg bg-gray-900 p-6 text-left">
          <h2 className="mb-3 text-xl font-semibold text-white">To run this project:</h2>
          <ol className="space-y-2 text-gray-300">
            <li>
              1. Install dependencies: <code className="rounded bg-gray-800 px-2 py-1">npm install</code>
            </li>
            <li>
              2. Start the dev server: <code className="rounded bg-gray-800 px-2 py-1">npm run dev</code>
            </li>
            <li>3. Open the Vite dev server URL in your browser</li>
          </ol>
          <div className="mt-4 rounded border border-gray-700 bg-gray-800 p-4">
            <p className="text-sm text-gray-400">The application includes:</p>
            <ul className="mt-2 list-inside list-disc space-y-1 text-sm text-gray-300">
              <li>Login page with authentication</li>
              <li>Dashboard with statistics and charts</li>
              <li>Rooms management</li>
              <li>Bookings management</li>
              <li>Customer management</li>
              <li>Billing system</li>
              <li>Settings page</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
